from django.db import models

# from django.db import models
#
#
# class Registration(models.Model):
#     firstname = models.CharField(max_length=20)
#     lastname = models.CharField(max_length=20)
#     email = models.CharField(max_length=30)
#     password = models.CharField(max_length=20)
#     confirm_password = models.CharField(max_length=20)
#
#     def __str__(self):
#         return self.firstname
