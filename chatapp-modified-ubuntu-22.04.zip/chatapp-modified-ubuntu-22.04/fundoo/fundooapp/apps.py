from django.apps import AppConfig


class FundooappConfig(AppConfig):
    name = 'fundooapp'
