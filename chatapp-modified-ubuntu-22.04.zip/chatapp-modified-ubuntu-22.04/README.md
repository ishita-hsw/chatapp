# Django-Chat-Application

# first install python 3.8 and make it default interpreter before installing requirement.txt
#https://www.youtube.com/watch?v=hAdympqE9v0&t=253s
